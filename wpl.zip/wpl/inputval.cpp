#include "inputval.h"
#include "serial.h"

InputValue::InputValue(QObject *parent) : QObject(parent)
{
/*    velo=0;
}
int InputValue::velocity(){
    return velo;
}
int InputValue::getSerial(int n){
    return n; */
}
