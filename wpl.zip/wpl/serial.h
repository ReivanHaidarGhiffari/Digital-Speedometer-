#ifndef SERIAL_H
#define SERIAL_H

#include <QObject>
#include <QSerialPort>
#include <QSerialPortInfo>

#include <QDebug>

class Serial : public QObject
{
    Q_OBJECT
public:
    explicit Serial(QObject *parent = nullptr);

    QSerialPort *serial;
    QSerialPortInfo *serialInfo;

    qint32 baudrate;
    QSerialPort::DataBits dataBits;
    QSerialPort::Parity parity;
    QSerialPort::StopBits stopBits;

    QString dataAll;

    Q_INVOKABLE void connectingDevice();

signals:
    void dataReceived(QString data);

public slots:
    void readData();

private:
    void setBaudrate();
    void setDataBits();
    void setParity();
    void setStopBits();

};

#endif // SERIAL_H
