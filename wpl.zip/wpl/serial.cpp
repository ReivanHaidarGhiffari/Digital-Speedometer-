#include "serial.h"
#include <sstream>

Serial::Serial(QObject *parent) : QObject(parent)
{
    serial = new QSerialPort();
    serialInfo = new QSerialPortInfo();

    connect(serial,SIGNAL(readyRead()),this,SLOT(readData()));
}

void Serial::connectingDevice()
{
    if (!serial->isOpen())
    {
        setBaudrate();
        setParity();
        setDataBits();
        setStopBits();
        serial->setPortName("COM7");
        serial->open(QIODevice::ReadWrite);
        qDebug() << "Serial is Connected";
        //        btConnect->setText("Disconnect");
    }
//    else
//    {
//        serial->close();
//        qDebug() << "Serial is Disconnected";
//        //        btConnect->setText("Connect");
//    }
}

void Serial::setBaudrate()
{
    baudrate = QSerialPort::Baud115200;
    serial->setBaudRate(baudrate);
}

void Serial::setDataBits()
{
    dataBits = QSerialPort::Data8;
    serial->setDataBits(dataBits);
}

void Serial::setParity()
{
    parity = QSerialPort::NoParity;
    serial->setParity(parity);
}

void Serial::setStopBits()
{
    stopBits = QSerialPort::OneStop;
    serial->setStopBits(stopBits);
}

void Serial::readData()
{
    static int parserState = 0;
    unsigned char dataChar;
    QByteArray data = serial->read(10);

    for (int i = 0; i < data.length(); i++)
    {
        dataChar = data[i];
        switch(parserState)
        {
        case 0:
            if (dataChar == '(')
            {
                dataAll.clear();
                parserState = 1;
            }
            break;
        case 1:
            if (dataChar == ')')
                parserState = 2;
            else
                dataAll += QChar(dataChar);
//                dataAll.append(QChar(dataChar));
            break;
        case 2:
                parserState = 0;
                emit dataReceived(dataAll);
            break;
        default:
            break;
        }
    }
}
//int Serial::getVelo(){
//    readData();
//    QString arr;
//    int i=0;
//     ssin(QLine);
//}
