#ifndef INPUTVAL_H
#define INPUTVAL_H
#include <QObject>
#include <QString>

class InputValue: public QObject
{
    Q_OBJECT
public:
    explicit InputValue(QObject *parent = nullptr);
signals:
   /* int velo;

    Q_INVOKABLE int velocity();
    Q_INVOKABLE int getSerial(int n); */
};
#endif // INPUTVAL_H
